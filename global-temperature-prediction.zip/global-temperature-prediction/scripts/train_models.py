import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from app.config import DATA_PATH, ARTIFACTS_DIR
from app.model import train_and_save, load_data

def make_plots(metrics, df):
    ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
    # EDA visualization: mean temperature by year
    trend = df.groupby("year")["avg_temperature"].mean()
    plt.figure(figsize=(9, 5))
    trend.plot()
    plt.title("Mean synthetic temperature by year")
    plt.xlabel("Year")
    plt.ylabel("Average temperature (°C)")
    plt.tight_layout()
    plt.savefig(ARTIFACTS_DIR / "eda_temperature_trend.png")
    plt.close()

    # Model vs baseline visualization
    labels = list(metrics["models"].keys()) + ["baseline"]
    values = [metrics["models"][name]["mae"] for name in metrics["models"]] + [metrics["baseline_mae"]]
    plt.figure(figsize=(9, 5))
    plt.bar(labels, values)
    plt.title("Model comparison: MAE (lower is better)")
    plt.ylabel("Mean absolute error")
    plt.tight_layout()
    plt.savefig(ARTIFACTS_DIR / "model_baseline_comparison.png")
    plt.close()

def main():
    if not DATA_PATH.exists():
        raise FileNotFoundError("Run python scripts/ingest_data.py first")
    metrics = train_and_save()
    make_plots(metrics, load_data())
    print(json.dumps(metrics, indent=2))
    print(f"Plots saved in {ARTIFACTS_DIR}")

if __name__ == "__main__":
    main()
