from pathlib import Path
import numpy as np
import pandas as pd
from app.config import DATA_PATH

COUNTRIES = {"India": 356, "Canada": 124, "Brazil": 76, "Australia": 36, "United Kingdom": 826,
             "Japan": 392, "Kenya": 404, "United States": 840}

def ingest_data(output_path=DATA_PATH, seed=42):
    # Deterministic synthetic demo data; replace with a verified real data source for research use.
    rng = np.random.default_rng(seed)
    rows = []
    for country, code in COUNTRIES.items():
        base = rng.uniform(4.0, 27.0)
        for year in range(1990, 2025):
            trend = (year - 1990) * rng.uniform(0.005, 0.025)
            seasonal_noise = rng.normal(0, 0.45)
            rows.append({"country": country, "country_code": code, "year": year,
                         "avg_temperature": round(base + trend + seasonal_noise, 3)})
    df = pd.DataFrame(rows)
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_path, index=False)
    return df

if __name__ == "__main__":
    df = ingest_data()
    print(f"Wrote {len(df)} rows to {DATA_PATH}")
