# Global Temperature Prediction API

A small, reproducible machine-learning capstone project that predicts average temperature from historical country/year observations. It includes a FastAPI service, data ingestion, EDA plots, model comparison, baseline evaluation, logging, performance timing, tests, and Docker support.

## Quick start (Python 3.11 recommended)

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
python scripts/ingest_data.py
python scripts/train_models.py
pytest -q
uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000/docs` for interactive API docs.

## API examples

- Health: `GET /health`
- Available countries: `GET /countries`
- Prediction for one country: `GET /predict?country=India&year=2030`
- Combined prediction across supported countries: `GET /predict?year=2030`

The combined prediction is the mean of predictions for the countries in the training data.

## Reproducible project workflow

1. `python scripts/ingest_data.py` creates a deterministic synthetic historical dataset in `data/temperature.csv`. This makes the repository runnable without downloading a third-party dataset.
2. `python scripts/train_models.py` trains Linear Regression and Random Forest models, saves the best model and metrics, and writes EDA/model-comparison plots to `artifacts/`.
3. `pytest -q` runs all unit tests in one command.
4. `uvicorn app.main:app --reload` launches the API.
5. `docker build -t global-temperature-api .` and `docker run -p 8000:8000 global-temperature-api` run the container.

## Notes for assessment

This repository is a runnable educational capstone template. The included dataset is **synthetic demonstration data**, not an authoritative climate dataset. For a research-grade project, replace it with a documented real source and describe its license and preprocessing in the report. Performance monitoring here records request duration in application logs; it is not a full production observability stack.

## Project structure

```text
app/                 FastAPI app, prediction and logging
scripts/             data ingestion and model training / plots
tests/               API, model, and logging tests
data/                generated dataset
artifacts/           trained model, metrics, and charts (generated)
Dockerfile
requirements.txt
```
