import logging
from pathlib import Path

def configure_logging(log_path: str | Path | None = None) -> logging.Logger:
    logger = logging.getLogger("temperature_api")
    logger.setLevel(logging.INFO)
    logger.propagate = False
    if not logger.handlers:
        handler = logging.FileHandler(log_path) if log_path else logging.StreamHandler()
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
        logger.addHandler(handler)
    return logger
