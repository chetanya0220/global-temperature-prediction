from __future__ import annotations
import time
from fastapi import FastAPI, HTTPException, Query
from app.config import DATA_PATH
from app.logging_config import configure_logging
from app.model import load_data, load_trained_model

app = FastAPI(title="Global Temperature Prediction API", version="1.0.0")
logger = configure_logging()

@app.middleware("http")
async def log_request_duration(request, call_next):
    start = time.perf_counter()
    response = await call_next(request)
    duration_ms = (time.perf_counter() - start) * 1000
    logger.info("method=%s path=%s status=%s duration_ms=%.2f",
                request.method, request.url.path, response.status_code, duration_ms)
    response.headers["X-Process-Time-ms"] = f"{duration_ms:.2f}"
    return response

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/countries")
def countries():
    if not DATA_PATH.exists():
        raise HTTPException(status_code=503, detail="Dataset missing. Run scripts/ingest_data.py")
    df = load_data()
    return {"countries": sorted(df["country"].unique().tolist())}

@app.get("/predict")
def predict(year: int = Query(ge=1850, le=2200), country: str | None = None):
    if not DATA_PATH.exists():
        raise HTTPException(status_code=503, detail="Dataset missing. Run scripts/ingest_data.py")
    try:
        bundle = load_trained_model()
        df = load_data()
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if country:
        matches = df.loc[df["country"].str.casefold() == country.casefold(), "country_code"]
        if matches.empty:
            raise HTTPException(status_code=404, detail=f"Unknown country: {country}")
        code = int(matches.iloc[0])
        value = float(bundle["model"].predict([[year, code]])[0])
        return {"country": country, "year": year, "predicted_avg_temperature": round(value, 3),
                "model": bundle["model_name"]}
    predictions = []
    for name, group in df.groupby("country"):
        code = int(group["country_code"].iloc[0])
        value = float(bundle["model"].predict([[year, code]])[0])
        predictions.append({"country": name, "predicted_avg_temperature": value})
    combined = sum(item["predicted_avg_temperature"] for item in predictions) / len(predictions)
    return {"country": "ALL", "year": year, "predicted_avg_temperature": round(combined, 3),
            "countries_included": len(predictions), "model": bundle["model_name"]}
