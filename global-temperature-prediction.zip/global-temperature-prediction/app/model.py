from __future__ import annotations
import joblib
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from app.config import DATA_PATH, MODEL_PATH, METRICS_PATH, ARTIFACTS_DIR

FEATURES = ["year", "country_code"]

def load_data(path=DATA_PATH) -> pd.DataFrame:
    df = pd.read_csv(path)
    required = {"country", "country_code", "year", "avg_temperature"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Dataset missing required columns: {sorted(missing)}")
    return df

def train_and_save(data_path=DATA_PATH) -> dict:
    df = load_data(data_path)
    X = df[FEATURES]
    y = df["avg_temperature"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    models = {
        "linear_regression": LinearRegression(),
        "random_forest": RandomForestRegressor(n_estimators=120, random_state=42, min_samples_leaf=2),
    }
    results = {}
    fitted = {}
    for name, model in models.items():
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        results[name] = {
            "mae": float(mean_absolute_error(y_test, pred)),
            "rmse": float(mean_squared_error(y_test, pred) ** 0.5),
            "r2": float(r2_score(y_test, pred)),
        }
        fitted[name] = model
    best_name = min(results, key=lambda n: results[n]["mae"])
    ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump({"model": fitted[best_name], "model_name": best_name}, MODEL_PATH)
    baseline = float(abs(y_test - y_train.mean()).mean())
    metrics = {"models": results, "best_model": best_name, "baseline_mae": baseline}
    METRICS_PATH.write_text(__import__("json").dumps(metrics, indent=2), encoding="utf-8")
    return metrics

def load_trained_model():
    if not MODEL_PATH.exists():
        raise FileNotFoundError("Model not found. Run: python scripts/train_models.py")
    return joblib.load(MODEL_PATH)
