import pytest
from fastapi.testclient import TestClient
from app.main import app
from scripts.ingest_data import ingest_data
from app.model import train_and_save
from app.config import DATA_PATH

@pytest.fixture(scope="session", autouse=True)
def prepare_demo_artifacts():
    ingest_data(DATA_PATH)
    train_and_save(DATA_PATH)

@pytest.fixture
def client():
    return TestClient(app)
