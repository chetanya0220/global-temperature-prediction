import logging
from app.logging_config import configure_logging

def test_logging_writes_to_file(tmp_path):
    path = tmp_path / "test.log"
    logger = logging.getLogger("temperature_api_test")
    logger.handlers.clear()
    logger.setLevel(logging.INFO)
    handler = logging.FileHandler(path)
    logger.addHandler(handler)
    logger.info("unit-test-log-entry")
    handler.flush()
    handler.close()
    logger.removeHandler(handler)
    assert "unit-test-log-entry" in path.read_text(encoding="utf-8")
