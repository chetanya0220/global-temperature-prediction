def test_health_endpoint(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_countries_endpoint(client):
    response = client.get("/countries")
    assert response.status_code == 200
    assert "India" in response.json()["countries"]

def test_country_prediction(client):
    response = client.get("/predict", params={"country": "India", "year": 2030})
    assert response.status_code == 200
    body = response.json()
    assert body["country"] == "India"
    assert body["year"] == 2030
    assert isinstance(body["predicted_avg_temperature"], float)

def test_combined_prediction(client):
    response = client.get("/predict", params={"year": 2030})
    assert response.status_code == 200
    assert response.json()["country"] == "ALL"
    assert response.json()["countries_included"] > 1

def test_unknown_country_returns_404(client):
    response = client.get("/predict", params={"country": "Atlantis", "year": 2030})
    assert response.status_code == 404
