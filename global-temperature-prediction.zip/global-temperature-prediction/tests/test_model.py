from scripts.ingest_data import ingest_data
from app.model import load_data, train_and_save
from app.config import DATA_PATH

def test_ingestion_creates_expected_schema(tmp_path):
    path = tmp_path / "temperature.csv"
    df = ingest_data(path)
    assert len(df) > 0
    assert {"country", "country_code", "year", "avg_temperature"}.issubset(df.columns)

def test_model_training_returns_comparable_metrics():
    metrics = train_and_save(DATA_PATH)
    assert "linear_regression" in metrics["models"]
    assert "random_forest" in metrics["models"]
    assert metrics["best_model"] in metrics["models"]
    assert metrics["baseline_mae"] >= 0
